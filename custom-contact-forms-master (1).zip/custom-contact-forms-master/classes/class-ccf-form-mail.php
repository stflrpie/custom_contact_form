<?php


class CCF_Form_Mail {
	private $data;

	public function __construct( $data ) {
		$this->data = $data;
	}

	public function send() {

	}
}
