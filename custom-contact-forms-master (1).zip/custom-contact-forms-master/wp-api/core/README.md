# WordPress REST API Core

This repository holds the infrastructure of the WordPress REST API.

Please note, neither issues nor pull requests should be filed here. Issues should be filed [on the main API repository](https://github.com/WP-API/WP-API) instead.

We're currently preparing the API for [WordPress core merge](https://core.trac.wordpress.org/ticket/33982), and this is our repository for creating patches for that.
